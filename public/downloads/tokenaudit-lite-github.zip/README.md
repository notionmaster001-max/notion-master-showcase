# TokenAudit Lite

**Stop burning $10–$20/day in hidden AI coding overages.**  
Zero-dependency, 100% offline CLI that audits your **Claude Code**, **Cursor**, **OpenAI**, **Gemini**, and **DeepSeek** usage logs in 2 seconds — detecting uncached prompt bloat, overkill flagship calls, and exact recoverable savings using November 2026 API rates.

## Quickstart (Zero Install)

```bash
node bin/tokenaudit.js analyze samples/sample-usage.jsonl
```

Or enforce a hard USD budget gate in CI/CD (exits with code `1` if exceeded):

```bash
node bin/tokenaudit.js analyze usage.csv --budget 50
```

Export machine-readable JSON:

```bash
node bin/tokenaudit.js analyze samples/sample-usage.jsonl --json > audit.json
```

## Supported Input Formats

- **JSONL** (Claude Code, Anthropic API, OpenAI API logs)
- **JSON** (array of usage objects)
- **CSV** (Cursor, OpenAI, Anthropic billing exports)

Auto-maps `input_tokens` / `prompt_tokens`, `cache_read_input_tokens` / `cached_tokens`, `output_tokens` / `completion_tokens`, and normalizes November 2026 model names (`claude-opus-5.5`, `claude-sonnet-5.5`, `claude-haiku-5.5`, `claude-fable-5.2`, `gpt-6.2-astra`, `gpt-6.2-sol`, `gpt-6-luna`, `gemini-3.8-flash`, `deepseek-flash`).

## Lite (Free, MIT) vs. Pro ($49 One-Time)

| Feature | TokenAudit Lite (GitHub) | TokenAudit Pro ($49) |
| --- | --- | --- |
| Offline CLI & Nov 2026 Rate Card | Included | Included |
| Prompt Bloat & Overkill Flags | Summary count | Per-session inspector + fix tags |
| Local Visual Dashboard (Charts) | — | Included (100% local HTML app) |
| Model Routing & Cache ROI Simulator | — | Included (interactive sliders) |
| GitHub Actions Budget Gate Workflow | — | Included (ready-to-drop YAML) |
| CFO / Accountant CSV & Markdown Export | — | Included (1-click download) |

**Get TokenAudit Pro ($49 Solo / $99 Team):** https://notionmaster001.gumroad.com/

## License

MIT
